EPHY STORE V11 — CUSTOMER AUTHENTICATION + DATABASE

This version adds a real SQLite database and secure password hashing/JWT customer sessions to the Express backend.

BACKEND SETUP
1. Open backend/
2. Copy .env.example to .env
3. Set a long random JWT_SECRET before deployment.
4. Run: npm install
5. Run: npm start
6. The SQLite database is created automatically in backend/data/ephy-store.db

API
POST /api/v11/auth/register
POST /api/v11/auth/login
GET  /api/v11/auth/me              (Bearer token)
GET  /api/v11/orders                (Bearer token)
POST /api/v11/orders                (Bearer token)

FRONTEND
Set window.EPHY_API_BASE to the URL where the backend is hosted before enabling real online customer accounts.
The V11 auth UI is intentionally separate from the older local-storage prototype features so the app remains testable offline.

SECURITY BEFORE PUBLIC LAUNCH
- Use HTTPS.
- Set a strong JWT_SECRET.
- Add rate limiting and server-side validation.
- Restrict CORS to your actual website/app origin.
- Use secure production database backups.
- Add password reset / phone verification.
- Replace the development admin PIN with proper admin authentication.
- Never put M-Pesa secrets, API keys, passwords, PINs, or OTPs in frontend code.

M-PESA
Still inactive. Add Safaricom Daraja only after the backend is securely deployed.
