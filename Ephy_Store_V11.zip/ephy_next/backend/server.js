
// --- V11 AUTH + SQLITE DATABASE LAYER ---
const Database = require("better-sqlite3");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const path = require("path");

const DATA_DIR = path.join(__dirname, "data");
require("fs").mkdirSync(DATA_DIR, { recursive: true });
const db = new Database(path.join(DATA_DIR, "ephy-store.db"));
db.pragma("journal_mode = WAL");

db.exec(`
CREATE TABLE IF NOT EXISTS customers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  phone TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS sessions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id INTEGER NOT NULL,
  token_id TEXT NOT NULL UNIQUE,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  expires_at TEXT NOT NULL,
  FOREIGN KEY(customer_id) REFERENCES customers(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS orders_v11 (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  customer_id INTEGER,
  order_no TEXT NOT NULL UNIQUE,
  total REAL NOT NULL,
  delivery_area TEXT,
  delivery_fee REAL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'Pending',
  items_json TEXT NOT NULL,
  customer_name TEXT NOT NULL,
  customer_phone TEXT NOT NULL,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(customer_id) REFERENCES customers(id) ON DELETE SET NULL
);
`);

const JWT_SECRET = process.env.JWT_SECRET || "CHANGE_THIS_SECRET_BEFORE_DEPLOYMENT";
const JWT_EXPIRES = process.env.JWT_EXPIRES || "7d";

function issueToken(customer) {
  return jwt.sign(
    { sub: String(customer.id), phone: customer.phone, name: customer.name },
    JWT_SECRET,
    { expiresIn: JWT_EXPIRES }
  );
}

function authCustomer(req, res, next) {
  const h = req.headers.authorization || "";
  const token = h.startsWith("Bearer ") ? h.slice(7) : "";
  if (!token) return res.status(401).json({ error: "Authentication required" });
  try {
    req.customer = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    return res.status(401).json({ error: "Invalid or expired session" });
  }
}

function cleanPhone(value) {
  return String(value || "").replace(/[^\d+]/g, "").trim();
}

app.post("/api/v11/auth/register", async (req, res) => {
  try {
    const { name, phone, password } = req.body || {};
    const cleanName = String(name || "").trim();
    const cleanPhoneNumber = cleanPhone(phone);
    if (!cleanName || !cleanPhoneNumber || !password || String(password).length < 6) {
      return res.status(400).json({ error: "Name, phone and a password of at least 6 characters are required" });
    }
    const existing = db.prepare("SELECT id FROM customers WHERE phone = ?").get(cleanPhoneNumber);
    if (existing) return res.status(409).json({ error: "An account already exists for this phone number" });
    const hash = await bcrypt.hash(String(password), 12);
    const info = db.prepare("INSERT INTO customers(name,phone,password_hash) VALUES(?,?,?)")
      .run(cleanName, cleanPhoneNumber, hash);
    const customer = { id: info.lastInsertRowid, name: cleanName, phone: cleanPhoneNumber };
    res.status(201).json({ customer, token: issueToken(customer) });
  } catch (e) {
    res.status(500).json({ error: "Could not create account" });
  }
});

app.post("/api/v11/auth/login", async (req, res) => {
  try {
    const { phone, password } = req.body || {};
    const cleanPhoneNumber = cleanPhone(phone);
    const row = db.prepare("SELECT * FROM customers WHERE phone = ?").get(cleanPhoneNumber);
    if (!row || !(await bcrypt.compare(String(password || ""), row.password_hash))) {
      return res.status(401).json({ error: "Invalid phone number or password" });
    }
    const customer = { id: row.id, name: row.name, phone: row.phone };
    res.json({ customer, token: issueToken(customer) });
  } catch {
    res.status(500).json({ error: "Could not sign in" });
  }
});

app.get("/api/v11/auth/me", authCustomer, (req, res) => {
  const row = db.prepare("SELECT id,name,phone,created_at FROM customers WHERE id = ?").get(Number(req.customer.sub));
  if (!row) return res.status(404).json({ error: "Customer not found" });
  res.json({ customer: row });
});

app.get("/api/v11/orders", authCustomer, (req, res) => {
  const rows = db.prepare(
    "SELECT order_no,total,delivery_area,delivery_fee,status,items_json,created_at FROM orders_v11 WHERE customer_id = ? ORDER BY id DESC"
  ).all(Number(req.customer.sub));
  res.json({ orders: rows.map(r => ({ ...r, items: JSON.parse(r.items_json) })) });
});

app.post("/api/v11/orders", authCustomer, (req, res) => {
  try {
    const { orderNo, total, deliveryArea, deliveryFee, items, customerName, customerPhone } = req.body || {};
    if (!orderNo || !Array.isArray(items) || !items.length || !Number.isFinite(Number(total))) {
      return res.status(400).json({ error: "Invalid order" });
    }
    const customer = db.prepare("SELECT id,name,phone FROM customers WHERE id = ?").get(Number(req.customer.sub));
    if (!customer) return res.status(401).json({ error: "Customer not found" });
    db.prepare(`
      INSERT INTO orders_v11(customer_id,order_no,total,delivery_area,delivery_fee,items_json,customer_name,customer_phone)
      VALUES(?,?,?,?,?,?,?,?)
    `).run(
      customer.id, String(orderNo), Number(total), String(deliveryArea || ""),
      Number(deliveryFee || 0), JSON.stringify(items),
      String(customerName || customer.name), String(customerPhone || customer.phone)
    );
    res.status(201).json({ ok: true, orderNo });
  } catch (e) {
    if (String(e.message).includes("UNIQUE")) return res.status(409).json({ error: "Order number already exists" });
    res.status(500).json({ error: "Could not save order" });
  }
});

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const PORT = Number(process.env.PORT || 3000);
const ADMIN_PIN = process.env.ADMIN_PIN || '1234';
const DATA_DIR = path.join(__dirname,'data');
const DB = path.join(DATA_DIR,'db.json');
if(!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR,{recursive:true});
const initial={
  products:[
    {id:1,cat:'Eggs',name:'Fresh Eggs',price:450,unit:'Tray of 30',icon:'🥚',stock:25,active:true},
    {id:2,cat:'Chicken',name:'Whole Chicken',price:700,unit:'Per bird',icon:'🐔',stock:15,active:true},
    {id:3,cat:'Vegetables',name:'Fresh Sukuma Wiki',price:50,unit:'Bunch',icon:'🥬',stock:40,active:true},
    {id:4,cat:'Vegetables',name:'Fresh Tomatoes',price:120,unit:'1 kg',icon:'🍅',stock:30,active:true},
    {id:5,cat:'Vegetables',name:'Fresh Onions',price:150,unit:'1 kg',icon:'🧅',stock:25,active:true},
    {id:6,cat:'Eggs',name:'Eggs',price:20,unit:'Each',icon:'🥚',stock:100,active:true}
  ],
  deliveryAreas:[{id:1,name:'Malindi Town',fee:100},{id:2,name:'Nearby Areas',fee:150},{id:3,name:'Outside Town',fee:250}],
  users:[], orders:[], settings:{name:'Ephy Store',phone:'+254796288206',mpesa:''}
};
function load(){if(!fs.existsSync(DB)){save(initial);return initial;} try{return JSON.parse(fs.readFileSync(DB,'utf8'));}catch(e){save(initial);return initial;}}
function save(db){fs.writeFileSync(DB,JSON.stringify(db,null,2));}
let db=load();
function send(res,status,data){res.writeHead(status,{'Content-Type':'application/json','Access-Control-Allow-Origin':'*','Access-Control-Allow-Headers':'Content-Type,X-Admin-Pin','Access-Control-Allow-Methods':'GET,POST,PATCH,DELETE,OPTIONS'});res.end(JSON.stringify(data));}
function body(req){return new Promise((resolve,reject)=>{let s='';req.on('data',c=>s+=c);req.on('end',()=>{try{resolve(s?JSON.parse(s):{})}catch(e){reject(e)}})});}
function admin(req){return req.headers['x-admin-pin']===ADMIN_PIN;}
function sendFile(res,file){try{const ext=path.extname(file);const types={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json; charset=utf-8'};res.writeHead(200,{'Content-Type':types[ext]||'application/octet-stream'});res.end(fs.readFileSync(file));}catch(e){send(res,404,{error:'File not found'});}}

const server=http.createServer(async(req,res)=>{
  if(req.method==='OPTIONS') return send(res,204,{});
  try{
    const url=new URL(req.url,`http://${req.headers.host}`);
    if(req.method==='GET'&&url.pathname==='/api/store') return send(res,200,{products:db.products.filter(p=>p.active),deliveryAreas:db.deliveryAreas,settings:{name:db.settings.name,phone:db.settings.phone,mpesa:db.settings.mpesa}});
    if(req.method==='GET'&&url.pathname==='/api/admin/check'){if(!admin(req))return send(res,401,{error:'Unauthorized'});return send(res,200,{ok:true});}
    if(req.method==='POST'&&url.pathname==='/api/users'){const b=await body(req);if(!b.name||!b.phone)return send(res,400,{error:'Name and phone required'});let u=db.users.find(x=>x.phone===b.phone);if(u){u.name=b.name;u.email=b.email||u.email||'';}else{u={id:crypto.randomUUID(),name:b.name,phone:b.phone,email:b.email||''};db.users.push(u);}save(db);return send(res,200,u);}
    if(req.method==='GET'&&url.pathname==='/api/orders'){let phone=url.searchParams.get('phone');return send(res,200,phone?db.orders.filter(o=>o.phone===phone):[]);}
    if(req.method==='POST'&&url.pathname==='/api/orders'){const o=await body(req);if(!o.name||!o.phone||!Array.isArray(o.items)||!o.items.length)return send(res,400,{error:'Invalid order'});for(const item of o.items){const p=db.products.find(x=>String(x.id)===String(item.id)&&x.active);const qty=Number(item.qty)||0;if(!p||qty<1)return send(res,400,{error:'Invalid product in order'});if(Number(p.stock)<qty)return send(res,409,{error:`Insufficient stock for ${p.name}`});}for(const item of o.items){const p=db.products.find(x=>String(x.id)===String(item.id));p.stock-=Number(item.qty);}const no=o.no||('EPHY-'+Date.now().toString().slice(-7));const order={...o,no,status:'Pending',createdAt:new Date().toISOString(),date:new Date().toLocaleString()};db.orders.unshift(order);save(db);return send(res,201,order);}
    if(req.url.startsWith('/api/admin/')&&!admin(req)) return send(res,401,{error:'Unauthorized'});
    if(req.method==='GET'&&url.pathname==='/api/admin/orders') return send(res,200,db.orders);
    if(req.method==='PATCH'&&url.pathname.startsWith('/api/admin/orders/')){const no=decodeURIComponent(url.pathname.split('/').pop()),b=await body(req),o=db.orders.find(x=>x.no===no);if(!o)return send(res,404,{error:'Order not found'});if(b.status)o.status=b.status;save(db);return send(res,200,o);}
    if(req.method==='DELETE'&&url.pathname.startsWith('/api/admin/orders/')){const no=decodeURIComponent(url.pathname.split('/').pop());db.orders=db.orders.filter(x=>x.no!==no);save(db);return send(res,200,{ok:true});}
    if(req.method==='GET'&&url.pathname==='/api/admin/products') return send(res,200,db.products);
    if(req.method==='POST'&&url.pathname==='/api/admin/products'){const p=await body(req);if(!p.name)return send(res,400,{error:'Product name required'});p.id=p.id||crypto.randomUUID();db.products.push(p);save(db);return send(res,201,p);}
    if(req.method==='PATCH'&&url.pathname.startsWith('/api/admin/products/')){const id=decodeURIComponent(url.pathname.split('/').pop()),b=await body(req),p=db.products.find(x=>String(x.id)===id);if(!p)return send(res,404,{error:'Product not found'});Object.assign(p,b);save(db);return send(res,200,p);}
    if(req.method==='DELETE'&&url.pathname.startsWith('/api/admin/products/')){const id=decodeURIComponent(url.pathname.split('/').pop());db.products=db.products.filter(x=>String(x.id)!==id);save(db);return send(res,200,{ok:true});}
    if(req.method==='GET'&&url.pathname==='/api/admin/delivery') return send(res,200,db.deliveryAreas);
    if(req.method==='POST'&&url.pathname==='/api/admin/delivery'){const d=await body(req);if(!d.name)return send(res,400,{error:'Area name required'});d.id=d.id||crypto.randomUUID();db.deliveryAreas.push(d);save(db);return send(res,201,d);}
    if(req.method==='PATCH'&&url.pathname.startsWith('/api/admin/delivery/')){const id=decodeURIComponent(url.pathname.split('/').pop()),b=await body(req),d=db.deliveryAreas.find(x=>String(x.id)===id);if(!d)return send(res,404,{error:'Area not found'});Object.assign(d,b);save(db);return send(res,200,d);}
    if(req.method==='DELETE'&&url.pathname.startsWith('/api/admin/delivery/')){const id=decodeURIComponent(url.pathname.split('/').pop());db.deliveryAreas=db.deliveryAreas.filter(x=>String(x.id)!==id);save(db);return send(res,200,{ok:true});}
    if(req.method==='GET'&&url.pathname==='/api/admin/settings') return send(res,200,db.settings);
    if(req.method==='PATCH'&&url.pathname==='/api/admin/settings'){db.settings={...db.settings,...await body(req)};save(db);return send(res,200,db.settings);}
    if(req.method==='GET' && (url.pathname==='/' || url.pathname==='/index.html')) return sendFile(res,path.join(__dirname,'..','index.html'));
    send(res,404,{error:'Not found'});
  }catch(e){send(res,500,{error:e.message});}
});
server.listen(PORT,()=>console.log(`Ephy Store API running on port ${PORT}`));
